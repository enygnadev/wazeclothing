"use client"

import type React from "react"
import { createContext, useContext, useEffect, useState } from "react"
import { useAuth } from "./auth-provider"
import type { CartItem } from "@/lib/types"
import { getCart, updateCart } from "@/lib/firebase/cart" // 🔥 Firebase integration

interface CartContextType {
  items: CartItem[]
  addItem: (item: Omit<CartItem, "quantity">) => void
  removeItem: (id: string) => void
  updateQuantity: (id: string, quantity: number) => void
  clearCart: () => void
  total: number
  itemCount: number
  isOpen: boolean
  setIsOpen: (open: boolean) => void
}

const CartContext = createContext<CartContextType>({
  items: [],
  addItem: () => {},
  removeItem: () => {},
  updateQuantity: () => {},
  clearCart: () => {},
  total: 0,
  itemCount: 0,
  isOpen: false,
  setIsOpen: () => {},
})

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([])
  const [isOpen, setIsOpen] = useState(false)
  const { user } = useAuth()

  // ✅ Adiciona item ao carrinho
  const addItem = (newItem: Omit<CartItem, "quantity">) => {
    setItems((prev) => {
      const exists = prev.find((item) => item.id === newItem.id)
      if (exists) {
        return prev.map((item) =>
          item.id === newItem.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        )
      }
      return [...prev, { ...newItem, quantity: 1 }]
    })
  }

  const removeItem = (id: string) => {
    setItems((prev) => prev.filter((item) => item.id !== id))
  }

  const updateQuantity = (id: string, quantity: number) => {
    if (quantity <= 0) {
      removeItem(id)
    } else {
      setItems((prev) =>
        prev.map((item) =>
          item.id === id ? { ...item, quantity } : item
        )
      )
    }
  }

  const clearCart = () => setItems([])

  const total = items.reduce((sum, item) => sum + item.price * item.quantity, 0)
  const itemCount = items.reduce((sum, item) => sum + item.quantity, 0)

  // ✅ Carrega carrinho salvo no Firebase ao fazer login
  useEffect(() => {
    const loadCart = async () => {
      if (user?.uid) {
        const saved = await getCart(user.uid)
        if (saved?.items) {
          const fullItems: CartItem[] = saved.items.map((i) => ({
            id: i.productId,
            title: "(carregado do Firestore)",
            price: 0,
            image: "",
            quantity: i.quantity,
          }))
          setItems(fullItems) // ⚠️ Customize isso se quiser salvar nome, imagem, etc
        }
      }
    }
    loadCart()
  }, [user])

  // ✅ Salva carrinho no Firebase sempre que mudar
  useEffect(() => {
    const syncToFirebase = async () => {
      if (user?.uid) {
        const simplified = items.map((item) => ({
          productId: item.id,
          quantity: item.quantity,
        }))
        await updateCart(user.uid, simplified)
      }
    }
    syncToFirebase()
  }, [items, user])

  return (
    <CartContext.Provider
      value={{
        items,
        addItem,
        removeItem,
        updateQuantity,
        clearCart,
        total,
        itemCount,
        isOpen,
        setIsOpen,
      }}
    >
      {children}
    </CartContext.Provider>
  )
}

export const useCart = () => useContext(CartContext)
