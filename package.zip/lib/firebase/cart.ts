import { doc, getDoc, setDoc } from "firebase/firestore"
import { getDb } from "./firestore"

interface CartItem {
  productId: string
  quantity: number
}

interface Cart {
  userId: string
  items: CartItem[]
  updatedAt: Date
}

export async function getCart(userId: string): Promise<Cart | null> {
  try {
    const db = getDb()
    const docRef = doc(db, "carts", userId)
    const docSnap = await getDoc(docRef)

    if (docSnap.exists()) {
      const data = docSnap.data()
      return {
        userId,
        items: data.items || [],
        updatedAt: data.updatedAt?.toDate() || new Date(),
      }
    }

    return null
  } catch (error) {
    console.error("Error fetching cart:", error)
    return null
  }
}

export async function updateCart(userId: string, items: CartItem[]): Promise<void> {
  try {
    const db = getDb()
    const docRef = doc(db, "carts", userId)
    await setDoc(
      docRef,
      {
        items,
        updatedAt: new Date(),
      },
      { merge: true },
    )
  } catch (error) {
    console.error("Error updating cart:", error)
    throw error
  }
}
